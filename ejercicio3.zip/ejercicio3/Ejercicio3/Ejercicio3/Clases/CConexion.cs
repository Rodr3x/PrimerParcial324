﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3.Clases
{
    internal class CConexion
    {
        NpgsqlConnection conex = new NpgsqlConnection();

        static string server = "localhost";
        static string bd = "DBSergio";
        static string user = "user324";
        static string pass = "kali";
        static string port = "5432";

        string cadenaConexion = "server=" + server + ";" + "port=" + port + ";" + "user id=" + user + ";" + "password=" + pass+ ";" + "database=" + bd + ";";

        public NpgsqlConnection establecerConexion() 
        {
            try 
            {
                conex.ConnectionString = cadenaConexion;
                conex.Open();
                //MessageBox.Show("Se conecto a la Base de Datos");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sin conexion, error: "+ex.ToString());
            }
            return conex;
        }

        public void cerrarConexion() 
        {
            conex.Close();
        }
    }
}
