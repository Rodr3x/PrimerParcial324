﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3.Clases
{
    internal class CPersona
    {
        public void mostrarPersonas(DataGridView tablaPersonas)
        {
            try
            {
                CConexion cConexion = new CConexion();
                tablaPersonas.DataSource = null;

                string query = @"
                                SELECT 
                                    p.PersonaID,
                                    p.Nombre,
                                    p.Apellido,
                                    p.FechaNacimiento,
                                    p.CI,
                                    cb.CuentaID,
                                    cb.TipoCuenta,
                                    cb.Saldo,
                                    cb.FechaApertura
                                FROM 
                                    Persona p
                                JOIN 
                                    CuentaBancaria cb ON p.PersonaID = cb.PersonaID;
                            ";

                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(query, cConexion.establecerConexion());

                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                tablaPersonas.DataSource = dataTable;

                cConexion.cerrarConexion();

            }
            catch (Exception ex)
            {
                MessageBox.Show("No se mostraron los datos: " + ex.ToString());
            }
        }


        public void guardarPersonaCuenta(TextBox nombres, TextBox apellidos, TextBox ci, string nac,
                                            ComboBox tcuenta, TextBox saldo, string apertura)
        {
            try
            {
                CConexion cConexion = new CConexion();
                string queryPersona = @"INSERT INTO Persona (Nombre, Apellido, FechaNacimiento, CI)
                                VALUES (@Nombre, @Apellido, @FechaNacimiento, @CI) RETURNING PersonaID;";

                string queryCuenta = @"INSERT INTO CuentaBancaria (PersonaID, TipoCuenta, Saldo, FechaApertura)
                               VALUES (@PersonaID, @TipoCuenta, @Saldo, @FechaApertura);";

                using (NpgsqlConnection conn = cConexion.establecerConexion())
                {
                    // Insertar Persona y obtener el ID generado
                    using (NpgsqlCommand cmdPersona = new NpgsqlCommand(queryPersona, conn))
                    {
                        cmdPersona.Parameters.AddWithValue("@Nombre", nombres.Text);
                        cmdPersona.Parameters.AddWithValue("@Apellido", apellidos.Text);
                        cmdPersona.Parameters.AddWithValue("@CI", ci.Text);
                        cmdPersona.Parameters.AddWithValue("@FechaNacimiento", DateTime.Parse(nac));

                        int personaId = (int)cmdPersona.ExecuteScalar();

                        // Insertar Cuenta Bancaria usando el PersonaID obtenido
                        using (NpgsqlCommand cmdCuenta = new NpgsqlCommand(queryCuenta, conn))
                        {
                            cmdCuenta.Parameters.AddWithValue("@PersonaID", personaId);
                            cmdCuenta.Parameters.AddWithValue("@TipoCuenta", tcuenta.Text);
                            cmdCuenta.Parameters.AddWithValue("@Saldo", Decimal.Parse(saldo.Text));
                            cmdCuenta.Parameters.AddWithValue("@FechaApertura", DateTime.Parse(apertura));

                            cmdCuenta.ExecuteNonQuery();
                        }
                    }
                    MessageBox.Show("Se guardaron los registros de Persona y Cuenta Bancaria correctamente");
                }
                cConexion.cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error con los datos: " + ex.Message);
            }
        }

        public void seleccionarPersona(DataGridView tablaAlumnos, TextBox id, TextBox nombres, TextBox apellidos,
                TextBox ci, DateTimePicker nac, ComboBox tcuenta, TextBox saldo, DateTimePicker apertura)
        {
            try
            {
                // Asumiendo que las celdas están en el orden correcto según el diseño de tu tabla.
                id.Text = tablaAlumnos.CurrentRow.Cells[0].Value.ToString();
                nombres.Text = tablaAlumnos.CurrentRow.Cells[1].Value.ToString();
                apellidos.Text = tablaAlumnos.CurrentRow.Cells[2].Value.ToString();
                ci.Text = tablaAlumnos.CurrentRow.Cells[4].Value.ToString();  // Asumiendo que el índice 4 es CI

                // Configurando las fechas directamente desde el DataGridView sin validación adicional
                nac.Value = Convert.ToDateTime(tablaAlumnos.CurrentRow.Cells[3].Value);
                apertura.Value = Convert.ToDateTime(tablaAlumnos.CurrentRow.Cells[8].Value);

                // Configurando el tipo de cuenta y saldo directamente
                tcuenta.SelectedItem = tablaAlumnos.CurrentRow.Cells[6].Value.ToString();
                saldo.Text = tablaAlumnos.CurrentRow.Cells[7].Value.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo seleccionar: " + ex.ToString());
            }
        }

        public void modificarPersonas(TextBox id, TextBox nombres, TextBox apellidos,
        TextBox ci, DateTimePicker nac, ComboBox tcuenta, TextBox saldo, DateTimePicker apertura)
        {
            string fechanac = nac.Value.ToString("yyyy-MM-dd");
            string fechaapertura = apertura.Value.ToString("yyyy-MM-dd");
            try
            {
                CConexion cConexion = new CConexion();
                string queryPersona = @"UPDATE Persona SET Nombre = @Nombre, Apellido = @Apellido, 
                                FechaNacimiento = @FechaNacimiento, CI = @CI
                                WHERE PersonaID = @PersonaID;";

                string queryCuenta = @"UPDATE CuentaBancaria SET TipoCuenta = @TipoCuenta, Saldo = @Saldo, 
                               FechaApertura = @FechaApertura
                               WHERE PersonaID = @PersonaID;";

                using (NpgsqlConnection conn = cConexion.establecerConexion())
                {

                    // Actualizar Persona
                    using (NpgsqlCommand cmdPersona = new NpgsqlCommand(queryPersona, conn))
                    {
                        cmdPersona.Parameters.AddWithValue("@PersonaID", int.Parse(id.Text));
                        cmdPersona.Parameters.AddWithValue("@Nombre", nombres.Text);
                        cmdPersona.Parameters.AddWithValue("@Apellido", apellidos.Text);
                        cmdPersona.Parameters.AddWithValue("@CI", ci.Text);
                        cmdPersona.Parameters.AddWithValue("@FechaNacimiento", DateTime.Parse(fechanac));

                        cmdPersona.ExecuteNonQuery();
                    }

                    // Actualizar Cuenta Bancaria
                    using (NpgsqlCommand cmdCuenta = new NpgsqlCommand(queryCuenta, conn))
                    {
                        cmdCuenta.Parameters.AddWithValue("@PersonaID", int.Parse(id.Text));
                        cmdCuenta.Parameters.AddWithValue("@TipoCuenta", tcuenta.SelectedItem.ToString());
                        cmdCuenta.Parameters.AddWithValue("@Saldo", Decimal.Parse(saldo.Text));
                        cmdCuenta.Parameters.AddWithValue("@FechaApertura", DateTime.Parse(fechaapertura));

                        cmdCuenta.ExecuteNonQuery();
                    }
                    MessageBox.Show("Se actualizaron los registros de Persona y Cuenta Bancaria correctamente");
                }
                cConexion.cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error con los datos: " + ex.Message);
            }
        }

        public void eliminarPersonaCuenta(TextBox id)
        {
            try
            {
                CConexion cConexion = new CConexion();
                using (NpgsqlConnection conn = cConexion.establecerConexion())
                {
                    // Iniciar una transacción
                    using (var transaction = conn.BeginTransaction())
                    {
                        // Consulta para eliminar la cuenta bancaria
                        string queryCuenta = "DELETE FROM CuentaBancaria WHERE PersonaID = @PersonaID;";
                        using (NpgsqlCommand cmdCuenta = new NpgsqlCommand(queryCuenta, conn))
                        {
                            cmdCuenta.Parameters.AddWithValue("@PersonaID", int.Parse(id.Text));
                            cmdCuenta.Transaction = transaction;
                            cmdCuenta.ExecuteNonQuery();
                        }

                        // Consulta para eliminar la persona
                        string queryPersona = "DELETE FROM Persona WHERE PersonaID = @PersonaID;";
                        using (NpgsqlCommand cmdPersona = new NpgsqlCommand(queryPersona, conn))
                        {
                            cmdPersona.Parameters.AddWithValue("@PersonaID", int.Parse(id.Text));
                            cmdPersona.Transaction = transaction;
                            cmdPersona.ExecuteNonQuery();
                        }

                        // Confirmar la transacción
                        transaction.Commit();
                        MessageBox.Show("Se eliminó el registro de la persona y su cuenta bancaria!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al momento de eliminar: " + ex.ToString());
            }
        }


    }
}
