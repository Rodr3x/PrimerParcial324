﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            txttcuenta.Items.Add("corriente");
            txttcuenta.Items.Add("ahorros");
            txttcuenta.Items.Add("nomina");
            Clases.CPersona objetoAlumno = new Clases.CPersona();
            objetoAlumno.mostrarPersonas(dgvTotalPersona);
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Clases.CPersona persona = new Clases.CPersona();
            string fechanac = txtnac.Value.ToString("yyyy-MM-dd");
            string fechaapertura = txtapertura.Value.ToString("yyyy-MM-dd");
            persona.guardarPersonaCuenta(txtnombres, txtapellidos, txtci, fechanac, txttcuenta, txtsaldo, fechaapertura);
            persona.mostrarPersonas(dgvTotalPersona);
        }

        private void dgvTotalAlumnos_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //NULL
        }


        private void dgvTotalPersona_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Clases.CPersona persona = new Clases.CPersona();
            persona.seleccionarPersona(dgvTotalPersona, txtid, txtnombres, txtapellidos, txtci, txtnac, txttcuenta, txtsaldo, txtapertura);
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            Clases.CPersona persona = new Clases.CPersona();
            persona.modificarPersonas(txtid, txtnombres, txtapellidos, txtci, txtnac, txttcuenta, txtsaldo, txtapertura);
            persona.mostrarPersonas(dgvTotalPersona);
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            Clases.CPersona persona = new Clases.CPersona();
            persona.eliminarPersonaCuenta(txtid);
            limpiar();
            persona.mostrarPersonas(dgvTotalPersona);
        }

        private void limpiar() 
        {
            txtid.Clear();
            txtnombres.Clear();
            txtapellidos.Clear();
            txtci.Clear();
            txttcuenta.Items.Clear();
            txtsaldo.Clear();       
        }
        private void label1_Click(object sender, EventArgs e)
        {
            //NULL

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //NULL

        }

        private void txtid_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
