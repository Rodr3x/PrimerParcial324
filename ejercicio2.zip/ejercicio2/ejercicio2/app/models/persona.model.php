<?php
require_once "../config/connection.php";
class Persona extends Connection
{
    public static function mostrarDatos()
    {
        try{
            
            $sql = "SELECT 
            p.PersonaID,
            p.Nombre,
            p.Apellido,
            p.FechaNacimiento,
            p.CI,
            cb.CuentaID,
            cb.TipoCuenta,
            cb.Saldo,
            cb.FechaApertura
            FROM 
                Persona p
            JOIN 
                CuentaBancaria cb ON p.PersonaID = cb.PersonaID;
            ";
            
            //$sql = "SELECT * FROM Persona";
            $stmt = Connection::getConnection() -> prepare($sql);
            $stmt -> execute();
            $result = $stmt -> fetchAll();
            return $result;
        }
        catch(PDOException $th){
            echo "Error: ".$th->getMessage();
        }
    }
    public static function obtenerDatosID($personaid)
    {
        try {
            $sql = "SELECT Persona.*, CuentaBancaria.* 
                    FROM Persona 
                    INNER JOIN CuentaBancaria ON Persona.PersonaID = CuentaBancaria.PersonaID 
                    WHERE Persona.PersonaID = :personaid";
            
            $stmt = Connection::getConnection()->prepare($sql);
            $stmt->bindParam(":personaid", $personaid);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result;
        } catch(PDOException $th) {
            echo "Error: ".$th->getMessage();
        }
    }


    public static function guardarDato($data)
    {
        try {
            $sql = "INSERT INTO Persona (Nombre, Apellido, FechaNacimiento, CI) 
                    VALUES (:nombre, :apellido, :fechanacimiento, :ci) RETURNING PersonaID";
            $stmt = Connection::getConnection()->prepare($sql);
            
            $stmt->bindParam(":nombre", $data['nombre']);
            $stmt->bindParam(":apellido", $data['apellido']);
            $stmt->bindParam(":fechanacimiento", $data['fechanacimiento']);
            $stmt->bindParam(":ci", $data['ci']);

            $stmt->execute();
            
            // Obtener el ID de la persona recién insertada
            return $stmt->fetchColumn();
        } catch(PDOException $th) {
            throw $th; // Lanzar la excepción para que se maneje en el controlador
        }
    }

public static function guardarDatoC($data)
    {
        try {
            $sql = "INSERT INTO CuentaBancaria (PersonaID, TipoCuenta, Saldo, FechaApertura) 
                    VALUES (:personaID, :tipocuenta, :saldo, :fechaapertura)";
            $stmt = Connection::getConnection()->prepare($sql);
            
            $stmt->bindParam(":personaID", $data['personaID']);
            $stmt->bindParam(":tipocuenta", $data['tipocuenta']);
            $stmt->bindParam(":saldo", $data['saldo']);
            $stmt->bindParam(":fechaapertura", $data['fechaapertura']);

            $stmt->execute();
            
            // Obtener el ID de la cuenta recién insertada
            return Connection::getConnection()->lastInsertId();
        } catch(PDOException $th) {
            throw $th; // Lanzar la excepción para que se maneje en el controlador
        }
    }

    

    public static function actualizarDato($data)
    {
        try {
            // Actualizar los datos de la persona
            $sqlPersona = "UPDATE Persona SET nombre = :nombre, apellido = :apellido, fechanacimiento = :fechanacimiento, ci = :ci WHERE personaid = :personaid";
            $stmtPersona = Connection::getConnection()->prepare($sqlPersona);
            
            $stmtPersona->bindParam(":nombre", $data['nombre']);
            $stmtPersona->bindParam(":apellido", $data['apellido']);
            $stmtPersona->bindParam(":fechanacimiento", $data['fechanacimiento']);
            $stmtPersona->bindParam(":ci", $data['ci']);
            $stmtPersona->bindParam(":personaid", $data['personaid']);
            
            $stmtPersona->execute();

            // Actualizar los datos de la cuenta bancaria
            $sqlCuenta = "UPDATE CuentaBancaria SET tipocuenta = :tipocuenta, saldo = :saldo, fechaapertura = :fechaapertura WHERE cuentaid = :cuentaid";
            $stmtCuenta = Connection::getConnection()->prepare($sqlCuenta);

            $stmtCuenta->bindParam(":tipocuenta", $data['tipocuenta']);
            $stmtCuenta->bindParam(":saldo", $data['saldo']);
            $stmtCuenta->bindParam(":fechaapertura", $data['fechaapertura']);
            $stmtCuenta->bindParam(":cuentaid", $data['cuentaid']); // Usar el ID de la cuenta bancaria

            $stmtCuenta->execute();

            // Si ambas actualizaciones tienen éxito, devuelve true
            return true;
        } catch(PDOException $th) {
            // En caso de error, manejarlo adecuadamente
            echo "Error: ".$th->getMessage();
            return false;
        }
    }



    public static function borrarDato($personaid)
    {
        try {
            // Iniciar una transacción para asegurar la consistencia de los datos
            Connection::getConnection()->beginTransaction();

            // Eliminar la cuenta bancaria asociada a la persona
            $sqlCuenta = "DELETE FROM CuentaBancaria WHERE PersonaID = :personaid";
            $stmtCuenta = Connection::getConnection()->prepare($sqlCuenta);
            $stmtCuenta->bindParam(":personaid", $personaid);
            $stmtCuenta->execute();

            // Eliminar la persona
            $sqlPersona = "DELETE FROM Persona WHERE PersonaID = :personaid";
            $stmtPersona = Connection::getConnection()->prepare($sqlPersona);
            $stmtPersona->bindParam(":personaid", $personaid);
            $stmtPersona->execute();

            // Confirmar la transacción
            Connection::getConnection()->commit();

            // Devolver true si la eliminación fue exitosa
            return true;

        } catch(PDOException $th) {
            // Rollback en caso de error
            Connection::getConnection()->rollback();
            // Manejar cualquier excepción
            echo "Error: ".$th->getMessage();
            return false;
        }
    }
}

?>