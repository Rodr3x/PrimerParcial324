<?php
require_once "../models/persona.model.php";

// Verificar si se han recibido los datos esperados
    // Crear un array asociativo con los datos del formulario
    $dataArray = array(
        'nombre' => $_POST['nombre'], 
        'apellido' => $_POST['apellido'],
        'fechanacimiento' => $_POST['fechanacimiento'],
        'ci' => $_POST['ci'],
        'personaid' => $_POST['personaid'],
        'cuentaid' => $_POST['cuentaid'],	
        'tipocuenta' => $_POST['tipocuenta'],
        'saldo' => $_POST['saldo'],
        'fechaapertura' => $_POST['fechaapertura']        
    );  

    // Intentar actualizar los datos en la base de datos y devolver la respuesta como JSON
    echo json_encode(Persona::actualizarDato($dataArray));

?>
