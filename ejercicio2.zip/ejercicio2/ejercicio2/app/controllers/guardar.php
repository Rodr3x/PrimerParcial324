<?php
require_once "../models/persona.model.php";

// Obtener datos del formulario
$arrayPersona = array(
    'nombre' => $_POST['nombre'], 
    'apellido' => $_POST['apellido'],
    'fechanacimiento' => $_POST['fechanacimiento'],
    'ci' => $_POST['ci']
);

$arrayCuenta = array(
    'tipocuenta' => $_POST['tipocuenta'],
    'saldo' => $_POST['saldo'],
    'fechaapertura' => $_POST['fechaapertura']
);

try {
    // Iniciar una transacción
    Connection::getConnection()->beginTransaction();

    // Insertar datos en la tabla Persona
    $personaID = Persona::guardarDato($arrayPersona);

    // Si la inserción en Persona fue exitosa
    if ($personaID) {
        // Insertar datos en la tabla CuentaBancaria
        $arrayCuenta['personaID'] = $personaID;
        $cuentaID = Persona::guardarDatoC($arrayCuenta);

        // Confirmar la transacción
        Connection::getConnection()->commit();

        echo json_encode(array('success' => true, 'message' => 'Datos guardados correctamente.'));
    } else {
        // Rollback si hubo un error al insertar en Persona
        Connection::getConnection()->rollback();
        echo json_encode(array('success' => false, 'message' => 'Error al guardar los datos de la Persona.'));
    }
} catch(PDOException $th) {
    // Rollback en caso de error
    Connection::getConnection()->rollback();
    // Manejar cualquier excepción
    echo json_encode(array('success' => false, 'message' => 'Error en la transacción: '.$th->getMessage()));
}
?>
