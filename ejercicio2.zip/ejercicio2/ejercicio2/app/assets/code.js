const app = new (function(){
    this.tbody = document.getElementById('tbody');
    this.personaid = document.getElementById('personaid');
    this.nombre = document.getElementById('nombre');
    this.apellido = document.getElementById('apellido');
    this.fechanacimiento = document.getElementById('fechanacimiento');
    this.ci = document.getElementById('ci');

    this.cuentaid = document.getElementById('cuentaid');
    this.tipocuenta = document.getElementById('tipocuenta');
    this.saldo = document.getElementById('saldo');
    this.fechaapertura = document.getElementById('fechaapertura');

    this.listado = () => 
    {
        fetch("../controllers/listado.php")
        .then((res) => res.json())
        .then((data)=>{
            console.log(data);
            this.tbody.innerHTML = "";
            data.forEach((item) =>
            {
                this.tbody.innerHTML += `
                <tr>
                    <td>${item.personaid}</td>
                    <td>${item.nombre}</td>
                    <td>${item.apellido}</td>
                    <td>${item.fechanacimiento}</td>
                    <td>${item.ci}</td>

                    <td>${item.cuentaid}</td>
                    <td>${item.tipocuenta}</td>
                    <td>${item.saldo}</td>
                    <td>${item.fechaapertura}</td>

                    <td>
                        <a href="javascript:;" class = "btn btn-warning btn-sm" onclick="app.editar(${item.personaid})">Editar</a>
                        <a href="javascript:;" class = "btn btn-danger btn-sm" onclick="app.eliminar(${item.personaid})">Eliminar</a> 
                    </td>
                </tr>
                `; 
            });
        })
        .catch((error) => console.log(error));
    };

    this.guardar = () => {  
        var form = new FormData();
    
        // Agregar los datos del formulario al objeto FormData
        form.append('personaid', this.personaid.value);
        form.append('nombre', this.nombre.value);
        form.append('apellido', this.apellido.value);
        form.append('fechanacimiento', this.fechanacimiento.value);
        form.append('ci', this.ci.value);
        
        form.append('cuentaid', this.cuentaid.value);
        form.append('tipocuenta', this.tipocuenta.value);
        form.append('saldo', this.saldo.value);
        form.append('fechaapertura', this.fechaapertura.value);
       
        if(this.personaid.value == "") {
            // Si no se proporciona un ID de persona, se trata de una inserción
            fetch("../controllers/guardar.php", {
                method: "POST",
                body: form,
            })
            .then((res) => res.json())
            .then((data) => {
                alert("CREADO CON ÉXITO!");
                this.listado();
                this.limpiar();
            })
            .catch((error) => console.log(error)); // Manejar cualquier error en la solicitud
        
            alert("CREADO CON ÉXITO!");
            setTimeout(function() {
                window.location.reload();
            }, 1000); // 1000 milisegundos = 1 segundos


        } else {
            //alert(this.personaid.value);

            // Si se proporciona un ID de persona, se trata de una actualización
            fetch("../controllers/actualizar.php", {
                method: "POST",
                body: form, 
            })
            .then((res) => res.json())
            .then((data) => {
                alert("ACTUALIZADO CON ÉXITO!");
                this.listado();
                this.limpiar();

            })
            .catch((error) => console.log(error)); // Manejar cualquier error en la solicitud
            /*
            alert("ACTUALIZADO CON ÉXITO!");
            setTimeout(function() {
                window.location.reload();
            }, 1000); // 1000 milisegundos = 1 segundos*/
        }
    };
    

    this.eliminar = (personaid) => {
        //alert(personaid);
        var form = new FormData();
        form.append('personaid', personaid);
        fetch("../controllers/eliminar.php", {
            method: "POST",
            body: form, 
        })
        .then((res) => res.json())
        .then((data) => {
            alert("ELIMINADO CON EXITO!");
            this.listado();
            this.limpiar();
        })
        .catch((error) => console.log(error));
        alert("ELIMINADO CON ÉXITO!");
        setTimeout(function() {
            window.location.reload();
        }, 1000); // 1000 milisegundos = 1 segundos
    };

    this.editar = (personaid) => {
        //alert(personaid);
        var form = new FormData();
        form.append('personaid', personaid);
        fetch("../controllers/editar.php", {
            method: "POST",
            body: form, 
        })
        .then((res) => res.json())
        .then((data) => {
            this.personaid.value = data.personaid;
            this.nombre.value = data.nombre;
            this.apellido.value = data.apellido;
            this.fechanacimiento.value = data.fechanacimiento;
            this.ci.value = data.ci;

            this.cuentaid.value = data.cuentaid;
            this.tipocuenta.value = data.tipocuenta;
            this.saldo.value = data.saldo;
            this.fechaapertura.value = data.fechaapertura;
            
            // Ir al inicio de la página
            window.scrollTo({
                top: 0,
                behavior: 'smooth' // Esto hace que el desplazamiento sea suave
            });
  
        })
        .catch((error) => console.log(error));
    };

    this.limpiar = () => {
        this.personaid.value= "";
        this.nombre.value = "";
        this.apellido.value = "";
        this.ci.value = "";
        this.fechanacimiento.value = "";

        this.cuentaid.value= "";
        this.tipocuenta.value = "";
        this.saldo.value = "";
        this.fechaapertura.value = "";
    };
})();   
app.listado();
