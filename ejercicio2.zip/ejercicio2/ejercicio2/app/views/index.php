<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Persona</title>
    <!-- Bootstrap CSS v5.2.0-beta1 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css"
        integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor"
        crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center p-5">
            <div class="col-lg-6">
                <h2 class="text-center mb-4">Formulario de Registro</h2>
                <form id="registration-form" action="javascript:void(0);" onsubmit="app.guardar()">
                    <input type="hidden" id="personaid" />
                    
                    <div class="mb-3">
                        <label for="nombre" class="form-label">Nombres</label>
                        <input type="text" class="form-control" id="nombre" placeholder="Ingrese sus nombres" autofocus required>
                    </div>
                    <div class="mb-3">
                        <label for="apellido" class="form-label">Apellidos</label>
                        <input type="text" class="form-control" id="apellido" placeholder="Ingrese sus apellidos" required>
                    </div>
                    
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="ci" class="form-label">Cédula de Identidad</label>
                                <input type="text" class="form-control" id="ci" placeholder="Ingrese su cédula de identidad">
                            </div>
                        </div>
                
                    <div class="mb-3">
                        <label for="fechanacimiento" class="form-label">Fecha de Nacimiento</label>
                        <input type="date" class="form-control" id="fechanacimiento" required>
                    </div>


                    <input type="hidden" id="cuentaid" />
                    <div class="mb-3">
                        <label for="tipocuenta" class="form-label">Tipo de Cuenta</label>
                        <select class="form-select" id="tipocuenta" required>
                            <option value="">Seleccione...</option>
                            <option value="corriente">Cuenta Corriente</option>
                            <option value="ahorros">Cuenta de Ahorros</option>
                            <option value="nomina">Cuenta de Nómina</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="saldo" class="form-label">Saldo</label>
                        <input type="number" class="form-control" id="saldo" placeholder="Ingrese el saldo" step="0.01">
                    </div>
                    <div class="mb-3">
                        <label for="fechaapertura" class="form-label">Fecha de Apertura</label>
                        <input type="date" class="form-control" id="fechaapertura" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                    <button type="reset" class="btn btn-secondary">Cancelar</button>
                </form>
            </div>
        </div>

        <div class="row justify-content-center mt-5">
            <div class="col-sm-10">
                <h2 class="text-center mb-4">Listado de Personas y Cuentas</h2>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>#ID_Persona</th>
                                <th>Nombre(s)</th>
                                <th>Apellido(s)</th>
                                <th>Fecha de Nacimiento</th>
                                <th>Cédula de Identidad</th>
                                <th>#ID_Cuenta</th>
                                <th>Tipo de Cuenta</th>
                                <th>Saldo</th>
                                <th>Fecha de Apertura</th>
                                <th>Opciones</th>
                            </tr>
                        </thead>
                        <tbody id="tbody" class="personas"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JavaScript Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js"
        integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js"
        integrity="sha384-kjU+l4N0Yf4ZOJErLsIcvOU2qSb74wXpOhqTvwVx3OElZRweTnQ6d31fXEoRD1Jy"
        crossorigin="anonymous"></script>
    <!-- Custom Script -->
    <script src="../assets/code.js"></script>
</body>
</html>
