<footer>
        <p>SERGIO RODRIGO PAYE YUJRA &copy; 2024</p>
    </footer>

</div>

</body>
</html>