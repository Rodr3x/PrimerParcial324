<?php include 'cabecera.php'; ?>

<div class="container">

    <header>
        <h1>Ejercicio 1</h1>
        <p>Realice un maquetado, con CSS y PHP. Donde muestre al menos tres tipos de cuentas bancarias.</p>   
    </header>

    <main>
        <section>
            <h2><i class="fas fa-money-check-alt"></i>Cuenta Corriente</h2>
            <p>Una cuenta corriente es un tipo de depósito a la vista que permite al cliente retirar el dinero en cualquier momento y sin preaviso. Suele utilizarse como cuenta central para operaciones bancarias del día a día, como ingresos, pagos, domiciliaciones de recibos, transferencias o retiradas de efectivo en cajeros automáticos, entre otras. También se conoce como depósito a la vista.</p>
        </section>
        <section>
            <h2><i class="fas fa-file-invoice-dollar"></i>Cuenta de Nomina</h2>
            <p>Una cuenta nómina es aquella cuenta corriente que, a cambio de domiciliar una nómina o pensión, nos proporciona algunas ventajas adicionales. En principio, este tipo de cuenta permite domiciliar nuestra nómina o pensión, pero también nuestros recibos de agua, luz, internet, teléfono o gas. Y además nos da la opción de realizar transferencias y traspasos; asociar tarjetas de débito y crédito; de ingresar cheques; de disponer de efectivo de cajeros y oficinas; y de realizar operaciones y gestionarla online.</p>
        </section>
        <section>
            <h2><i class="fas fa-piggy-bank"></i>Cuenta de Ahorro</h2>
            <p>Una cuenta ahorro es una modalidad de depósito bancario a la vista que permite rentabilizar los ahorros, ya que el cliente deposita una cantidad de dinero en la entidad bancaria y esta, a cambio, le paga en función de los intereses generados. La rentabilidad obtenida vendrá determinada por el periodo de tiempo que el dinero se mantenga depositado en la entidad bancaria.</p>
        </section>
        <section>
            <h2><i class="fas fa-laptop"></i>Cuenta Online</h2>
            <p>Una cuenta online es un tipo de cuenta bancaria que el propio cliente se abre online utilizando la web o la app de la entidad bancaria. En este tipo de cuentas, el contrato entre el cliente y el banco se realiza a través de internet.</p>
        </section>
        <section>
            <h2><i class="fas fa-coins"></i>Cuenta Remunerada</h2>
            <p>Una cuenta remunerada es un tipo de cuenta bancaria que ofrece al cliente un tipo de interés a cambio de tener el dinero depositado en la entidad.
            La remuneración y el tipo de interés ofrecido variará en función de la entidad, las condiciones de la cuenta y el momento. Este tipo de interés se aplica al saldo que exista en la cuenta durante un periodo de tiempo limitado. En general no existe una cantidad mínima de dinero para abrir una cuenta remunerada pero la rentabilidad será mayor cuanto mayor sea la cantidad depositada en la cuenta remunerada.</p>
        </section>
        
    </main>

<?php include 'pie.php'; ?>