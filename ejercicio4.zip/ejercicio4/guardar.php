<?php
    $host = 'localhost';
    $dbname = 'DBSergio';
    $port = '5432';  // Puerto predeterminado de PostgreSQL
    $username = 'user324';
    $password = 'kali';
    $dsn = "pgsql:host=$host;port=$port;dbname=$dbname;user=$username;password=$password";

    try {
        $conn = new PDO($dsn);

        if ($conn) {
            echo "Conectado a la base de datos $dbname con éxito!";
        }
    } catch (PDOException $e) {
        die("No se pudo conectar a la base de datos: " . $e->getMessage());
    }


    $nombre = $_GET['nombre'];
    $apellido = $_GET['apellido'];
    $fechanacimiento = $_GET['fechanacimiento'];
    $ci = $_GET['ci'];
    $destino = $_GET['destino'];

    $sql = "INSERT INTO Persona (nombre, apellido, fechanacimiento, ci) VALUES (:nombre, :apellido, :fechanacimiento, :ci)";

    $stmt = $conn->prepare($sql);

    $stmt->bindParam(':nombre', $nombre);
    $stmt->bindParam(':apellido', $apellido);
    $stmt->bindParam(':fechanacimiento', $fechanacimiento);
    $stmt->bindParam(':ci', $ci);

    if ($stmt->execute()) {
        if ($destino == "java") {
            $url = "http://localhost:8080/WebApplication5/NewServlet?nombre=" . urlencode($nombre) . "&apellido=" . urlencode($apellido) . "&fechanacimiento=" . urlencode($fechanacimiento) . "&ci=" . urlencode($ci);
        } else if ($destino == "net") {
            $url = "http://localhost:59175/Default.aspx?nombre=" . urlencode($nombre) . "&apellido=" . urlencode($apellido) . "&fechanacimiento=" . urlencode($fechanacimiento) . "&ci=" . urlencode($ci);
        }
        header("Location: $url");
    } else {
        echo "Error: " . $stmt->errorInfo()[2];
    }

    $conn = null;
?>
