<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formularios Estilizados</title>
    <style>
        body {
            font-family: Arial, sans-serif; /* Tipografía más limpia */
            background-color: #f4f4f4; /* Color de fondo más suave */
            padding: 20px; /* Espaciado alrededor del contenido de la página */
        }
        form {
            background-color: white; /* Fondo blanco para los formularios */
            padding: 20px; /* Espaciado dentro de cada formulario */
            border-radius: 8px; /* Bordes redondeados */
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); /* Sombra sutil */
            margin-bottom: 20px; /* Espaciado entre formularios */
            width: 300px; /* Ancho fijo para los formularios */
        }
        input[type="text"] {
            width: calc(100% - 22px); /* Ancho completo menos el padding */
            padding: 10px; /* Espaciado dentro de los campos de texto */
            margin-top: 5px; /* Espaciado superior para cada campo de texto */
            margin-bottom: 15px; /* Espaciado inferior después de cada campo */
            border: 1px solid #ddd; /* Borde sutil */
            border-radius: 4px; /* Bordes ligeramente redondeados */
        }
        input[type="submit"] {
            background-color: #007BFF; /* Color de fondo para el botón */
            color: white; /* Texto blanco para el botón */
            border: none; /* Sin bordes */
            padding: 10px 20px; /* Espaciado dentro del botón */
            border-radius: 4px; /* Bordes redondeados para el botón */
            cursor: pointer; /* Cursor tipo pointer para indicar clic */
            width: 100%; /* Ancho completo */
        }
        input[type="submit"]:hover {
            background-color: #0056b3; /* Cambio de color al pasar el ratón */
        }
    </style>
</head>
<body>
    <!-- JAVA -->
    <form action="guardar.php" method="GET">
        <input type="hidden" name="destino" value="java">
        Nombre: <input type="text" name="nombre"/><br>
        Apellido: <input type="text" name="apellido"/><br>
        CI: <input type="text" name="ci"/><br>
        Fecha Nac: <input type="date" name="fechanacimiento"/><br>
        <br>
        <input type="submit" name="Enviar" value="Enviar JAVA">
    </form>

    <!-- .NET -->
    <form action="guardar.php" method="GET">
        <input type="hidden" name="destino" value="net">
        Nombre: <input type="text" name="nombre"/><br>
        Apellido: <input type="text" name="apellido"/><br>
        CI: <input type="text" name="ci"/><br>
        Fecha Nac: <input type="date" name="fechanacimiento"/><br>
        <br>
        <input type="submit" name="Enviar" value="Enviar NET">
    </form>
</body>
</html>
