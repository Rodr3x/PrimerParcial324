﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string nombre = Request.Params["nombre"];
            string apellido = Request.Params["apellido"];
            string fechanac = Request.Params["fechanacimiento"];
            string ci = Request.Params["ci"];

            LabelNombre.Text = nombre;
            LabelApellido.Text = apellido;
            LabelFecha.Text = fechanac;
            LabelCi.Text = ci;

        }
    }
}
