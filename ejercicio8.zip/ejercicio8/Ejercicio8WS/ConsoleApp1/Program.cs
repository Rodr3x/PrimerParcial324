﻿using System;

namespace MiProyecto
{
    class Program
    {
        static void Main(string[] args)
        {
            // Crear una instancia del cliente del servicio web
            var clienteWS = new Ejercicio8WS.WSCRUD.WSCRUD();

            // Llamar al método InsertarPersona
            string resultadoInsertar = clienteWS.InsertarPersona("Nombre", "Apellido", "1990-01-01", "1234567");

            // Imprimir el resultado
            Console.WriteLine("Resultado de insertar persona: " + resultadoInsertar);

            // Llamar al método ModificarPersona
            string resultadoModificar = clienteWS.ModificarPersona("NuevoNombre", "NuevoApellido", "1995-01-01", "1234567");

            // Imprimir el resultado
            Console.WriteLine("Resultado de modificar persona: " + resultadoModificar);

            // Llamar al método EliminarPersona
            string resultadoEliminar = clienteWS.EliminarPersona("1234567");

            // Imprimir el resultado
            Console.WriteLine("Resultado de eliminar persona: " + resultadoEliminar);
        }
    }
}
