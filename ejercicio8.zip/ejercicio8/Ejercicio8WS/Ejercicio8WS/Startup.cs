﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Ejercicio8WS.Startup))]
namespace Ejercicio8WS
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
