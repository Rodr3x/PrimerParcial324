﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace Ejercicio8WS.WSCRUD
{
    /// <summary>
    /// Descripción breve de WSCRUD
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class WSCRUD : System.Web.Services.WebService
    {
        [WebMethod]
        public string InsertarPersona(string nombre, string apellido, string fecha, string ci)
        {
            string mensaje = ""; // Mensaje para indicar el resultado de la operación

            string server = "localhost";
            string bd = "DBSergio";
            string user = "user324";
            string pass = "kali";
            string port = "5432";

            string cadenaConexion = "Server=" + server + ";" + "Port=" + port + ";" + "User Id=" + user + ";" + "Password=" + pass + ";" + "Database=" + bd + ";";

            // Crear la conexión a la base de datos
            using (NpgsqlConnection conex = new NpgsqlConnection(cadenaConexion))
            {
                try
                {
                    conex.Open(); // Abrir la conexión

                    // Consulta SQL para insertar datos en la tabla "Directivos"
                    string sql = "INSERT INTO Persona (Nombre, Apellido, FechaNacimiento, CI) VALUES (@Nombre, @Apellido, @FechaNacimiento, @CI)";

                    // Crear un objeto NpgsqlCommand con la consulta y la conexión
                    using (NpgsqlCommand miComando = new NpgsqlCommand(sql, conex))
                    {
                        // Agregar parámetros a la consulta
                        miComando.Parameters.AddWithValue("@Nombre", nombre);
                        miComando.Parameters.AddWithValue("@Apellido", apellido);
                        miComando.Parameters.AddWithValue("@FechaNacimiento", DateTime.Parse(fecha));
                        miComando.Parameters.AddWithValue("@CI", ci);

                        // Ejecutar la consulta con ExecuteNonQuery para insertar los datos
                        int filasAfectadas = miComando.ExecuteNonQuery();

                        // Verificar si se insertaron correctamente los datos
                        if (filasAfectadas > 0)
                        {
                            mensaje = "Los datos se insertaron correctamente.";
                        }
                        else
                        {
                            mensaje = "No se pudieron insertar los datos.";
                        }
                    }
                    return "Insercion correcta!";
                }
                catch (Exception ex)
                {
                    mensaje = "Error al intentar insertar los datos: " + ex.Message;
                }
            }

            return mensaje; // Devolver el mensaje resultante
        }

        [WebMethod]
        public string ModificarPersona(string nombre, string apellido, string fecha, string ci)
        {
            string mensaje = ""; // Mensaje para indicar el resultado de la operación

            string server = "localhost";
            string bd = "DBSergio";
            string user = "user324";
            string pass = "kali";
            string port = "5432";

            string cadenaConexion = "Server=" + server + ";" + "Port=" + port + ";" + "User Id=" + user + ";" + "Password=" + pass + ";" + "Database=" + bd + ";";

            // Crear la conexión a la base de datos
            using (NpgsqlConnection conex = new NpgsqlConnection(cadenaConexion))
            {
                try
                {
                    conex.Open(); // Abrir la conexión

                    // Consulta SQL para actualizar los datos de una persona en la tabla "Persona"
                    string sql = "UPDATE Persona SET Nombre = @Nombre, Apellido = @Apellido, FechaNacimiento = @FechaNacimiento WHERE CI = @CI";

                    // Crear un objeto NpgsqlCommand con la consulta y la conexión
                    using (NpgsqlCommand miComando = new NpgsqlCommand(sql, conex))
                    {
                        // Agregar parámetros a la consulta
                        miComando.Parameters.AddWithValue("@Nombre", nombre);
                        miComando.Parameters.AddWithValue("@Apellido", apellido);
                        miComando.Parameters.AddWithValue("@FechaNacimiento", DateTime.Parse(fecha));
                        miComando.Parameters.AddWithValue("@CI", ci);

                        // Ejecutar la consulta con ExecuteNonQuery para modificar los datos
                        int filasAfectadas = miComando.ExecuteNonQuery();

                        // Verificar si se modificaron correctamente los datos
                        if (filasAfectadas > 0)
                        {
                            mensaje = "Los datos se modificaron correctamente.";
                        }
                        else
                        {
                            mensaje = "No se encontró ninguna persona con el CI proporcionado.";
                        }
                    }
                }
                catch (Exception ex)
                {
                    mensaje = "Error al intentar modificar los datos: " + ex.Message;
                }
            }

            return mensaje; // Devolver el mensaje resultante
        }

        [WebMethod]
        public string EliminarPersona(string ci)
        {
            string mensaje = ""; // Mensaje para indicar el resultado de la operación

            string server = "localhost";
            string bd = "DBSergio";
            string user = "user324";
            string pass = "kali";
            string port = "5432";

            string cadenaConexion = "Server=" + server + ";" + "Port=" + port + ";" + "User Id=" + user + ";" + "Password=" + pass + ";" + "Database=" + bd + ";";

            // Crear la conexión a la base de datos
            using (NpgsqlConnection conex = new NpgsqlConnection(cadenaConexion))
            {
                try
                {
                    conex.Open(); // Abrir la conexión

                    // Consulta SQL para eliminar una persona de la tabla "Persona" basándose en el CI (Cédula de Identidad)
                    string sql = "DELETE FROM Persona WHERE CI = @CI";

                    // Crear un objeto NpgsqlCommand con la consulta y la conexión
                    using (NpgsqlCommand miComando = new NpgsqlCommand(sql, conex))
                    {
                        // Agregar el parámetro CI a la consulta
                        miComando.Parameters.AddWithValue("@CI", ci);

                        // Ejecutar la consulta con ExecuteNonQuery para eliminar la persona
                        int filasAfectadas = miComando.ExecuteNonQuery();

                        // Verificar si se eliminó correctamente la persona
                        if (filasAfectadas > 0)
                        {
                            mensaje = "La persona se eliminó correctamente.";
                        }
                        else
                        {
                            mensaje = "No se encontró ninguna persona con el CI proporcionado.";
                        }
                    }
                }
                catch (Exception ex)
                {
                    mensaje = "Error al intentar eliminar la persona: " + ex.Message;
                }
            }

            return mensaje; // Devolver el mensaje resultante
        }
    }
}
