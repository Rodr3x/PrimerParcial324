﻿using System.Web.UI;

namespace Ejercicio8WS.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}