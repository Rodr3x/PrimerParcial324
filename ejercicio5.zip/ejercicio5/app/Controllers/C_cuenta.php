<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\m_cuenta;
class C_cuenta extends Controller{

    public function index()
    {

        $c = new m_cuenta();
        $datos['cuentas']=$c->findAll();
        return view('welcome_message',$datos);
    }

    
    public function eliminar($id=null)
    {
        
    
       $c = new m_cuenta();
        $c->delete($id);

        
        return redirect()->to(base_url());
    }
}